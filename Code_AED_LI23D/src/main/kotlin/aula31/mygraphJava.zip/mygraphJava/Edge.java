package aula31.mygraphJava;

/**
 * Code adapted from Sedgewick's Book "Algorithms in Java"
 *
 */
public class Edge implements Comparable<Edge> {
    /**
     * Vertices v and w
     */
    int v, w;
    /**
     * Edge weight
     */
    double weight;

    /**
     * Constructor
     * @param v
     * @param w
     */
    public Edge(int v, int w) {
        this.v = v;
        this.w = w;
        this.weight = 1;
    }
    /**
     * Constructor
     * @param v
     * @param w
     * @param weight
     */
    public Edge(int v, int w, double weight) {
        this.v = v;
        this.w = w;
        this.weight = weight;
    }

    @Override
    public int compareTo(Edge edge) {
        // Compare two double taking into account rounding errors
        return Double.compare(this.weight, edge.weight);
    }
}
