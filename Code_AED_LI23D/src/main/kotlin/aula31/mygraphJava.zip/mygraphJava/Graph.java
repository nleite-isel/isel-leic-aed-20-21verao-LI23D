package aula31.mygraphJava;

/**
 * Code adapted from Sedgewick's Book "Algorithms in Java"
 *
 * ADT interface
 */
public interface Graph {
    int getNumVertices();
    int getNumEdges();
    boolean isDirected();
    void insert(Edge edge);
    void remove(Edge edge);
    boolean existsEdge(int v1, int v2);
    AdjList getAdjList(int v);
}
