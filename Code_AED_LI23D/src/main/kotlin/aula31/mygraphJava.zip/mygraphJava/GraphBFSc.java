package aula31.mygraphJava;

import mygraph.queue.QueueArrayImpl;

/**
 * Code adapted from Sedgewick's Book "Algorithms in Java"
 *
 * Breadth First Search (DFS)
 */
public class GraphBFSc {
    private Graph graph;
    private boolean[] visited;

    // Constructor
    public GraphBFSc(Graph graph, int v) {
        this.graph = graph;
        visited = new boolean[graph.getNumVertices()]; // Initialised to false
        // BFS search
        searchC(new Edge(v, v));
    }

    private void searchC(Edge e) {
        QueueArrayImpl<Edge> edgeQueue = new QueueArrayImpl<>(Edge.class, graph.getNumVertices());
        edgeQueue.put(e);
        while (!edgeQueue.isEmpty()) {
            if (!visited[(e = edgeQueue.get()).w]) {
                int v = e.v, w = e.w;
                visited[w] = true;
                ///////////////////////////
                /// DEBUG
                System.out.println("Visited vertice " + w);
                ///////////////////////////
                AdjList adjList = graph.getAdjList(w);
                for (int t = adjList.begin(); !adjList.end(); t = adjList.next()) {
                    if (!visited[t])
                        edgeQueue.put(new Edge(w, t));
                }
            }
        }
    }
}













