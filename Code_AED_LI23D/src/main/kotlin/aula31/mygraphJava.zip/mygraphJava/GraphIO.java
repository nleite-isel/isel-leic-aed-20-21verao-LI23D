package aula31.mygraphJava;

/**
 * Code adapted from Sedgewick's Book "Algorithms in Java"
 *
 * ADT interface
 */
public class GraphIO {

    public static Edge[] edges(Graph graph) {
        int e = 0;
        Edge[] edges = new Edge[graph.getNumEdges()];
        for (int v = 0; v < graph.getNumVertices(); v++) {
            AdjList a = graph.getAdjList(v);
            for (int w = a.begin(); !a.end(); w = a.next()) {
                if (graph.isDirected() || v < w)
                    edges[e++] = new Edge(v, w);
            }
        }
        return edges;
    }

    public static void show(Graph graph) {
        for (int s = 0; s < graph.getNumVertices(); s++) {
            System.out.print(s + ": ");
            AdjList A = graph.getAdjList(s);
            for (int t = A.begin(); !A.end(); t = A.next()) {
                System.out.print(t + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        System.out.println("\nDFS Example:");

        int numVertices = 13;
        ///
        /// SEE, AND EXPLAIN, THE DIFFERENCE BETWEEN OUTPUTS USING ADJACENCY MATRIX AND ADJACENCY LIST IMPLEMENTATIONS
        ///

        //////////////////////////////////////////////////////////////////////////////
//        Graph graph = new GraphAdjacencyListImpl(numVertices, false);
        Graph graph = new GraphAdjacencyMatrixImpl(numVertices, false);

        // Add edges
        graph.insert(new Edge(0, 5));
        graph.insert(new Edge(4, 3));
        graph.insert(new Edge(0, 1));
        graph.insert(new Edge(9, 12));
        graph.insert(new Edge(6, 4));
        graph.insert(new Edge(5, 4));

        graph.insert(new Edge(0, 2));
        graph.insert(new Edge(11, 12));
        graph.insert(new Edge(9, 10));
        graph.insert(new Edge(0, 6));

        graph.insert(new Edge(7, 8));
        graph.insert(new Edge(9, 11));
        graph.insert(new Edge(5, 3));

        GraphIO.show(graph);
        System.out.print(graph.getNumEdges() + " edges ");

        System.out.println("\nPerform DFS on a connected graph:");
        // Perform DFS on a connected graph. Only performs DFS on subgraph starting at vertice 0.
        GraphDFSc dfSc = new GraphDFSc(graph, 0);
        //////////////////////////////////////////////////////////////////////////////


        System.out.println("\nBFS Example:");

        int numVertices1 = 8;
        Graph graph1 = new GraphAdjacencyMatrixImpl(numVertices1, false);

        // Add edges
        graph1.insert(new Edge(0, 2));
        graph1.insert(new Edge(0, 5));
        graph1.insert(new Edge(0, 7));
        graph1.insert(new Edge(2, 6));
        graph1.insert(new Edge(6, 4));
        graph1.insert(new Edge(7, 1));
        graph1.insert(new Edge(5, 3));
        graph1.insert(new Edge(5, 4));
        graph1.insert(new Edge(4, 3));
        graph1.insert(new Edge(4, 7));

        GraphIO.show(graph1);
        System.out.print(graph1.getNumEdges() + " edges ");


        System.out.println("\nPerform BFS on a connected graph:");
        // Perform BFS on a connected graph. Only performs BFS on subgraph starting at vertice 0.
        GraphBFSc bfSc = new GraphBFSc(graph1, 0);
        //////////////////////////////////////////////////////////////////////////////
    }
}
