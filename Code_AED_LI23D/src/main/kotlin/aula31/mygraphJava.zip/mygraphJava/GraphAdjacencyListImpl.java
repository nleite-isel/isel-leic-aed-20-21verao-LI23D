package aula31.mygraphJava;

/**
 * Code adapted from Sedgewick's Book "Algorithms in Java"
 *
 * sparse multigraph implementation
 */
public class GraphAdjacencyListImpl implements Graph {
    private int vcnt, ecnt;
    private boolean digraph;

    private class Node {
        int v;
        Node next;
        Node(int x, Node t) {
            v = x;
            next = t;
        }
    }

    private Node[] adj;

    public GraphAdjacencyListImpl(int numVertices, boolean isDigraph) {
        vcnt = numVertices;
        ecnt = 0;
        digraph = isDigraph;
        adj = new Node[numVertices];
    }

    @Override
    public int getNumVertices() { return vcnt; }

    @Override
    public int getNumEdges() { return ecnt; }

    @Override
    public boolean isDirected() { return digraph; }

    @Override
    public void insert(Edge e) {
        int v = e.v, w = e.w;
        adj[v] = new Node(w, adj[v]);

        if (!digraph)
            adj[w] = new Node(v, adj[w]);
        ecnt++;
    }

    @Override
    public void remove(Edge edge) {
        throw new UnsupportedOperationException();

        // TO DO

    }

    @Override
    public boolean existsEdge(int v1, int v2) {
        throw new UnsupportedOperationException();

        // TO DO

    }

    @Override
    public AdjList getAdjList(int v) {
        return new AdjLinkedList(v);
    }

    private class AdjLinkedList implements AdjList
    {
        private int v;
        private Node t;

        public AdjLinkedList(int v) {
            this.v = v;
            t = null;
        }

        @Override
        public int begin() {
            t = adj[v];
            return t == null ? -1 : t.v;
        }

        @Override
        public int next() {
            if (t != null)
                t = t.next;
            return t == null ? -1 : t.v;
        }

        @Override
        public boolean end() {
            return t == null;
        }
    }
}
