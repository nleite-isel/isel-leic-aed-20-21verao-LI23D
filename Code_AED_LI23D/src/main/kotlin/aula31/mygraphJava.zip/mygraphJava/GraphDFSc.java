package aula31.mygraphJava;

/**
 * Code adapted from Sedgewick's Book "Algorithms in Java"
 *
 * Depth First Search (DFS)
 */
public class GraphDFSc {
    private Graph graph;
    private boolean[] visited;

    // Constructor
    public GraphDFSc(Graph graph, int v) {
        this.graph = graph;
        visited = new boolean[graph.getNumVertices()]; // Initialised to false
        searchC(v);
    }

    private void searchC(int v) {
        visited[v] = true;
        ///////////////////////////
        /// DEBUG
        System.out.println("Visited vertice " + v);
        ///////////////////////////
        AdjList adjList = graph.getAdjList(v);
        for (int t = adjList.begin(); !adjList.end(); t = adjList.next()) {
            if (!visited[t])
                searchC(t);
        }
    }

}