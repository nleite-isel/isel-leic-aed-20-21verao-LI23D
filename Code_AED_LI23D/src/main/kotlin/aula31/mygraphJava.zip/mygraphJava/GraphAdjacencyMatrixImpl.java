package aula31.mygraphJava;

/**
 * Code adapted from Sedgewick's Book "Algorithms in Java"
 *
 * ADT interface
 */
public class GraphAdjacencyMatrixImpl implements Graph {

    private int vcnt, ecnt;
    private boolean digraph;
    private boolean adj[][];

    public GraphAdjacencyMatrixImpl(int numVertices, boolean isDigraph) {
        vcnt = numVertices;
        ecnt = 0;
        digraph = isDigraph;
        adj = new boolean[numVertices][numVertices];
    }
    @Override
    public int getNumVertices() {
        return vcnt;
    }
    @Override
    public int getNumEdges() {
        return ecnt;
    }

    @Override
    public boolean isDirected() {
        return digraph;
    }

    @Override
    public void insert(Edge e) {
        int v = e.v, w = e.w;
        if (adj[v][w] == false)
            ecnt++;
        adj[v][w] = true;

        if (!digraph)
            adj[w][v] = true;
    }

    @Override
    public void remove(Edge e) {
        int v = e.v, w = e.w;
        if (adj[v][w] == true)
            ecnt--;

        adj[v][w] = false;

        if (!digraph)
            adj[w][v] = false;
    }

    @Override
    public boolean existsEdge(int v, int w) {
        return adj[v][w];
    }

    @Override
    public AdjList getAdjList(int v) {
        return new AdjArray(v);
    }

    private class AdjArray implements AdjList {
        private int i, v;

        public AdjArray(int numVertices) {
            this.v = numVertices;
            i = -1;
        }

        @Override
        public int begin() {
            i = -1;
            return next();
        }

        @Override
        public int next() {
            for (i++; i < getNumVertices(); i++) {
                if (existsEdge(v, i) == true)
                    return i;
            }
            return -1;
        }

        @Override
        public boolean end() {
            return i >= getNumVertices();
        }
    }


}

