
package aula31.mygraphJava.queue;

public interface Queue<E> {
	public void put(E e);
	public E get();
	public boolean isEmpty();
}