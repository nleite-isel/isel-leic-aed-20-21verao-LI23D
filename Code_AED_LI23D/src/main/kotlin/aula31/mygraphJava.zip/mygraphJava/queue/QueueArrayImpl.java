
package aula31.mygraphJava.queue;

import java.lang.reflect.Array;

public class QueueArrayImpl<E> implements Queue<E> {
	private E[] queue;
	private int head, tail, size, capacity;
	/**
	 * Constructor
	 *
	 * @param capacity
	 */
	public QueueArrayImpl(Class < E > elementType, int capacity) {
		this.capacity = capacity;
		queue = (E[]) Array.newInstance(elementType, capacity);
		head = 0; 
		tail = 0;
	}
	public void put(E elem){
		if (size < capacity) {
			queue[tail] = elem;
			tail = (tail+1) % capacity;
			++size;
		}
	}
	// Assume-se que antes de invocar o metodo get e' testado se a fila esta' vazia
	public E get(){
		E elem = queue[head];
		head = (head+1) % capacity;
		--size; 
		return elem;
	}
	public boolean isEmpty() {
		return size == 0;
	}
}