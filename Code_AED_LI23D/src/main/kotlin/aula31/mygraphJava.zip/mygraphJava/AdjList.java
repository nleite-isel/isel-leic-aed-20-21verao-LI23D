package aula31.mygraphJava;

/**
 * Code adapted from Sedgewick's Book "Algorithms in Java"
 *
 */
public interface AdjList {
    int begin();
    int next();
    boolean end();
}
